package com.example.mid_terms

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class ProductActivity : AppCompatActivity() {

    private val productPrice = 120

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_product)

        val txtProductPrice = findViewById<TextView>(R.id.txtPrice)
        val btnAddToCart = findViewById<Button>(R.id.btnAddToCart)

        txtProductPrice.text = productPrice.toString()

        btnAddToCart.setOnClickListener {
            val intent = Intent(this, MyCartActivity::class.java)
            intent.putExtra("price", productPrice)
            startActivity(intent)
        }
    }
}