package com.example.mid_terms

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

class MyCartActivity : AppCompatActivity() {

    private var unitPrice: Int = 0
    private var quantity: Int = 1

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_my_cart)

        val imgBack = findViewById<ImageView>(R.id.imgBack)
        val txtItemPrice = findViewById<TextView>(R.id.txtItemPrice)
        val txtQuantity = findViewById<TextView>(R.id.txtQuantity)
        val txtTotal = findViewById<TextView>(R.id.txtTotal)
        val btnPlus = findViewById<ImageView>(R.id.btnPlus)
        val btnMinus = findViewById<ImageView>(R.id.btnMinus)
        val btnPlaceOrder = findViewById<Button>(R.id.btnPlaceOrder)

        // ფასის მიღება ProductActivity-დან
        unitPrice = intent.getIntExtra("price", 0)

        // საწყისი მონაცემები ეკრანზე
        txtItemPrice.text = "$unitPrice$"
        txtQuantity.text = quantity.toString()
        txtTotal.text = "Total: ${unitPrice * quantity}$"

        // უკან წასვლა
        imgBack.setOnClickListener {
            finish()
        }

        // რაოდენობა +
        btnPlus.setOnClickListener {
            quantity++
            updateTotal(txtQuantity, txtTotal)
        }

        // რაოდენობა -
        btnMinus.setOnClickListener {
            if (quantity > 1) {
                quantity--
                updateTotal(txtQuantity, txtTotal)
            }
        }

        // Place Order → Success Screen
        btnPlaceOrder.setOnClickListener {
            val intent = Intent(this, SuccessActivity::class.java)
            startActivity(intent)
        }
    }

    private fun updateTotal(txtQuantity: TextView, txtTotal: TextView) {
        txtQuantity.text = quantity.toString()
        txtTotal.text = "Total: ${unitPrice * quantity}$"
    }
}